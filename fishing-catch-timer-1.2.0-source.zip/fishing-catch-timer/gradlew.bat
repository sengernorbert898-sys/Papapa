@echo off
setlocal
set "ROOT=%~dp0."
set VERSION=9.8.2
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set CACHE=%GRADLE_USER_HOME%\fishing-catch-timer-bootstrap\gradle-%VERSION%
if not exist "%CACHE%\bin\gradle.bat" (
  if not exist "%GRADLE_USER_HOME%\fishing-catch-timer-bootstrap" mkdir "%GRADLE_USER_HOME%\fishing-catch-timer-bootstrap"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%GRADLE_USER_HOME%\fishing-catch-timer-bootstrap\gradle.zip'; Expand-Archive -Force '%GRADLE_USER_HOME%\fishing-catch-timer-bootstrap\gradle.zip' '%GRADLE_USER_HOME%\fishing-catch-timer-bootstrap'; Remove-Item '%GRADLE_USER_HOME%\fishing-catch-timer-bootstrap\gradle.zip'"
)
call "%CACHE%\bin\gradle.bat" -p "%ROOT%" %*
endlocal
